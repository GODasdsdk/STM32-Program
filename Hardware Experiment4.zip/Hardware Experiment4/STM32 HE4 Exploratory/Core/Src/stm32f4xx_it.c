/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f4xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
extern int toUpdatefor500ms;
extern int toUpdatefor1000ms;
extern int timer[8];
int count1=0;
int count2=0;
char instruction[15]={0,0,0,0,0,
											0,0,0,0,0,
											0,0,0,0,0};
int insind=0;
extern int editmode;
extern int changechartodigit(char ch);
extern char changedigittochar(int digit);
int whattoedit=0;
int inspectinstruction(void);
char setseconds[15]={'s','e','t',' ','s',
										 'e','c','o','n','d',
										 's','\\','n',0,0};
char setminutes[15]={'s','e','t',' ','m',
										 'i','n','u','t','e',
										 's','\\','n',0,0};
char sethours[15]={'s','e','t',' ','h',
										 'o','u','r','s','\\',
										 'n',0,0,0,0};
char setall[15]={'s','e','t',' ','a',
										 'l','l','\\','n',0,
										 0,0,0,0,0};

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/

/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
   while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Pre-fetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */

  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F4xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f4xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles ADC1, ADC2 and ADC3 interrupts.
  */
void ADC_IRQHandler(void)
{
  /* USER CODE BEGIN ADC_IRQn 0 */
	
  /* USER CODE END ADC_IRQn 0 */

  /* USER CODE BEGIN ADC_IRQn 1 */

  /* USER CODE END ADC_IRQn 1 */
}

/**
  * @brief This function handles USART2 global interrupt.
  */
void USART2_IRQHandler(void)
{
  /* USER CODE BEGIN USART2_IRQn 0 */
	unsigned char rb; 
	int i; 
	/* USART2 所有事件共享同一个中断处理函数，因此其中要做出判断是否为RXNE中断 */ 
	if(LL_USART_IsActiveFlag_RXNE(USART2)){
	/* 如果奇偶校验正确才执行 */ 
		if(!LL_USART_IsActiveFlag_PE(USART2)){
			instruction[insind]=LL_USART_ReceiveData8(USART2);
			insind++;
			if(insind>=15){
				for(int t=0;t<15;t++) instruction[t]=NULL;
				insind=0;
			}
			int inspector=inspectinstruction();
			if(inspector==1){
				int length=0;
				if(editmode==2){
					if(whattoedit==1){
						timer[0]=changechartodigit(instruction[1]);
						timer[1]=changechartodigit(instruction[0]);
					}
					else if(whattoedit==2){
						timer[3]=changechartodigit(instruction[1]);
						timer[4]=changechartodigit(instruction[0]);
					}
					else if(whattoedit==3){
						timer[6]=changechartodigit(instruction[1]);
						timer[7]=changechartodigit(instruction[0]);
					}
					else if(whattoedit==4){
						for(int t=0;t<8;t++){
							timer[7-t]=changechartodigit(instruction[t]);
						}
					}
					if(timer[1]==6||timer[1]==8||timer[1]==9||timer[1]==10) timer[1]=5;
					if(timer[4]==6||timer[4]==8||timer[4]==9||timer[4]==10) timer[4]=5;
					if(timer[7]==2||timer[7]==4||timer[7]==5||
						 timer[7]==6||timer[7]==8||timer[7]==9||timer[7]==10) timer[7]=1;
					if(timer[7]==0||timer[7]==1){
						if(timer[6]==6||timer[6]==8||timer[6]==9||timer[6]==10) timer[6]=5;
					}else{
						if(timer[6]==4||timer[6]==5||
							 timer[6]==6||timer[6]==8||timer[6]==9||timer[6]==10) timer[6]=4;
					}
					editmode=0;
				}
				if(strcmp(instruction,setseconds)==0){
					updateContent("input seconds you want to set:(ss\\n)", 36);
					editmode=2;
					whattoedit=1;
				}
				if(strcmp(instruction,setminutes)==0){
					updateContent("input minutes you want to set:(mm\\n)", 36);
					editmode=2;
					whattoedit=2;
				}
				if(strcmp(instruction,sethours)==0){
					updateContent("input hours you want to set:(hh\\n)", 34);
					editmode=2;
					whattoedit=3;
				}
				if(strcmp(instruction,setall)==0){
					updateContent("input all you want to set:(hh:mm:ss\\n)", 38);
					editmode=2;
					whattoedit=4;
				}
				for(int t=0;t<15;t++) instruction[t]=NULL;
			}
			
			while(!LL_USART_IsActiveFlag_TXE(USART2)) continue;
		}
		LL_USART_ClearFlag_RXNE(USART2); //清除 RXNE 标志位 
		LL_USART_ClearFlag_PE(USART2); //清除奇偶校验错误标志位 
	}
  /* USER CODE END USART2_IRQn 0 */
  /* USER CODE BEGIN USART2_IRQn 1 */

  /* USER CODE END USART2_IRQn 1 */
}

/**
  * @brief This function handles TIM7 global interrupt.
  */
void TIM7_IRQHandler(void)
{
  /* USER CODE BEGIN TIM7_IRQn 0 */
	LL_GPIO_ResetOutputPin(RCLK_GPIO_Port,RCLK_Pin); //RCLK low
  
  out_595(LED[disp_ind]);  //send block code
  out_595(0x01<<disp_ind);  //send bit code
  
  LL_GPIO_SetOutputPin(RCLK_GPIO_Port,RCLK_Pin); //RCLK high, 74HC595 output
  
  /* move to next bit location */
  if(++disp_ind > 7) disp_ind = 0;
  
  /* clear UIF for TIM7 */
  LL_TIM_ClearFlag_UPDATE(TIM7);

  /* USER CODE END TIM7_IRQn 0 */
  /* USER CODE BEGIN TIM7_IRQn 1 */
	count1+=1;
	count2+=1;
	if(count1>=501){
		toUpdatefor500ms=1;
	}
	if(count1>=1001){
		count1=0;
		toUpdatefor500ms=2;
	}
	if(count2>=1001){
		count2=0;
		toUpdatefor1000ms=1;
	}
	
  /* USER CODE END TIM7_IRQn 1 */
}

/* USER CODE BEGIN 1 */
int inspectinstruction(void){
	int i=0;
	for(int t=0;t<15;t++){
		if(instruction[t]=='\\'){
			i=t;
			break;
		}
	}
	if(instruction[i+1]=='n'){
		insind=0;
		return 1;
	}
	return 0;
}
/* USER CODE END 1 */
