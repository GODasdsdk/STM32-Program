/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f4xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_it.h"
#include "stdio.h"
#include "string.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
extern int toUpdate;
int count=0;
int stustring[15]={-3,-3,-3,-3,-3,
										-3,-3,-3,-3,-3,
										-3,-3,-3,-3,-3};
int index=0;
extern int studentnum[];
extern int updateStunum;
extern int haventinput;
int updateInd=0;
/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/

/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
   while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Pre-fetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */

  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F4xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f4xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles ADC1, ADC2 and ADC3 interrupts.
  */
void ADC_IRQHandler(void)
{
  /* USER CODE BEGIN ADC_IRQn 0 */

  /* USER CODE END ADC_IRQn 0 */

  /* USER CODE BEGIN ADC_IRQn 1 */

  /* USER CODE END ADC_IRQn 1 */
}

/**
  * @brief This function handles USART2 global interrupt.
  */
void USART2_IRQHandler(void)
{
  /* USER CODE BEGIN USART2_IRQn 0 */
	unsigned char rb; 
	int i; 
	/* USART2 所有事件共享同一个中断处理函数，因此其中要做出判断是否为RXNE中断 */ 
	if(LL_USART_IsActiveFlag_RXNE(USART2)){
	/* 如果奇偶校验正确才执行 */ 
		if(!LL_USART_IsActiveFlag_PE(USART2)){
			rb=LL_USART_ReceiveData8(USART2);
			switch(rb){
				case '0':
					stustring[index]=13;
					break;
				case '1':
					stustring[index]=0;
					break;
				case '2':
					stustring[index]=1;
					break;
				case '3':
					stustring[index]=2;
					break;
				case '4':
					stustring[index]=4;
					break;
				case '5':
					stustring[index]=5;
					break;
				case '6':
					stustring[index]=6;
					break;
				case '7':
					stustring[index]=8;
					break;
				case '8':
					stustring[index]=9;
					break;
				case '9':
					stustring[index]=10;
					break;
				case '\\':
					stustring[index]=-2;
					break;
				case 'n':
					stustring[index]=-1;
					break;
				
			}
			if(index>=11){
				/*int k=0;
				for(k=0;;k++){
					if(stustring[k]==-3) break;
				}*/
				//stustring[9]
				if(stustring[10]==-2&&stustring[11]==-1){
					for(int t=0;t<10;t++){
						studentnum[t]=stustring[t];
						for(int t=0;t<10000;t++);
					}
				}
				for(int t=0;t<15;t++){
					stustring[t]=-3;
				}
				haventinput=0;
				index=0;
				
			}
			else index++;
			while(!LL_USART_IsActiveFlag_TXE(USART2)) continue;
		}
		LL_USART_ClearFlag_RXNE(USART2); //清除 RXNE 标志位 
		LL_USART_ClearFlag_PE(USART2); //清除奇偶校验错误标志位 
	}
	if(updateStunum==1){
		switch(studentnum[updateInd]){
			case 13:
				LL_USART_TransmitData8(USART2,'0');
				break;
			case 0:
				LL_USART_TransmitData8(USART2,'1');
				break;
			case 1:
				LL_USART_TransmitData8(USART2,'2');
				break;
			case 2:
				LL_USART_TransmitData8(USART2,'3');
				break;
			case 4:
				LL_USART_TransmitData8(USART2,'4');
				break;
			case 5:
				LL_USART_TransmitData8(USART2,'5');
				break;
			case 6:
				LL_USART_TransmitData8(USART2,'6');
				break;
			case 8:
				LL_USART_TransmitData8(USART2,'7');
				break;
			case 9:
				LL_USART_TransmitData8(USART2,'8');
				break;
			case 10:
				LL_USART_TransmitData8(USART2,'9');
				break;
		}
		updateInd++;
		
		if(updateInd>10){
			updateInd=0;
			updateStunum=0;
			LL_USART_TransmitData8(USART2,'\n');
		}
	}
	
  /* USER CODE END USART2_IRQn 0 */
  /* USER CODE BEGIN USART2_IRQn 1 */

  /* USER CODE END USART2_IRQn 1 */
}

/**
  * @brief This function handles TIM7 global interrupt.
  */
void TIM7_IRQHandler(void)
{
  /* USER CODE BEGIN TIM7_IRQn 0 */
	LL_GPIO_ResetOutputPin(RCLK_GPIO_Port,RCLK_Pin); //RCLK low
  
  out_595(LED[disp_ind]);  //send block code
  out_595(0x01<<disp_ind);  //send bit code
  
  LL_GPIO_SetOutputPin(RCLK_GPIO_Port,RCLK_Pin); //RCLK high, 74HC595 output
  
  /* move to next bit location */
  if(++disp_ind > 7) disp_ind = 0;
  
  /* clear UIF for TIM7 */
  LL_TIM_ClearFlag_UPDATE(TIM7);

  /* USER CODE END TIM7_IRQn 0 */
  /* USER CODE BEGIN TIM7_IRQn 1 */
	count+=1;
	if(count>=501){
		count=0;
		toUpdate=1;
	}
  /* USER CODE END TIM7_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
