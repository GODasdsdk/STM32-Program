#ifndef __STATUS_H
#define __STATUS_H
extern int settingsFlag;
extern int iterations;
extern int mode;
extern int i;
#endif