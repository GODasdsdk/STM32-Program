/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f4xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_it.h"
#include "..\\..\\status.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/

/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
   while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Pre-fetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */

  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F4xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f4xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles EXTI line 0 interrupt.
  */
#define DELAY 1000000
void delay100ms()
{
  uint32_t count=100000;
  while(count--) ;
}
extern int settingsFlag;
extern int mode;
extern int i;
GPIO_TypeDef * LED_port2[8] = {GPIOA,GPIOA,GPIOA,GPIOB,GPIOC,GPIOA,GPIOA,GPIOB};
uint32_t LED_pin2[8] = {LL_GPIO_PIN_5,LL_GPIO_PIN_6,LL_GPIO_PIN_7,LL_GPIO_PIN_6,
                       LL_GPIO_PIN_7,LL_GPIO_PIN_9,LL_GPIO_PIN_8,LL_GPIO_PIN_10};


int stopReply=0;
void EXTI0_IRQHandler(void)
{
  /* USER CODE BEGIN EXTI0_IRQn 0 */
	if(settingsFlag==1){
		delay100ms();
	}
	if(stopReply==1) return;
  /* USER CODE END EXTI0_IRQn 0 */
  if (LL_EXTI_IsActiveFlag_0_31(LL_EXTI_LINE_0) != RESET)
  {
    LL_EXTI_ClearFlag_0_31(LL_EXTI_LINE_0);
    /* USER CODE BEGIN LL_EXTI_LINE_0 */
		delay100ms();
		if(settingsFlag==1&&stopReply==0){
			mode++;
			
			if(mode>8){
				mode=1;
				LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_5);
				LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_6);
				LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_7);
				LL_GPIO_ResetOutputPin(GPIOB,LL_GPIO_PIN_6);
				LL_GPIO_ResetOutputPin(GPIOC,LL_GPIO_PIN_7);
				LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_9);
				LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_8);
				LL_GPIO_ResetOutputPin(GPIOB,LL_GPIO_PIN_10);
			}
			switch(mode){
				case 1:
					iterations=DELAY*5;
					LL_GPIO_SetOutputPin(LED_port2[0], LED_pin2[0]);
					break;
				case 2:
					iterations=DELAY*4;
					LL_GPIO_SetOutputPin(LED_port2[0], LED_pin2[0]);
					LL_GPIO_SetOutputPin(LED_port2[1], LED_pin2[1]);
					break;
				case 3:
					iterations=DELAY*3;
				  LL_GPIO_SetOutputPin(LED_port2[0], LED_pin2[0]);
					LL_GPIO_SetOutputPin(LED_port2[1], LED_pin2[1]);
					LL_GPIO_SetOutputPin(LED_port2[2], LED_pin2[2]);
					break;
				case 4:
					iterations=DELAY*2;
				  LL_GPIO_SetOutputPin(LED_port2[0], LED_pin2[0]);
					LL_GPIO_SetOutputPin(LED_port2[1], LED_pin2[1]);
					LL_GPIO_SetOutputPin(LED_port2[2], LED_pin2[2]);
					LL_GPIO_SetOutputPin(LED_port2[3], LED_pin2[3]);
					break;
				case 5:
					iterations=DELAY*1;
				  LL_GPIO_SetOutputPin(LED_port2[0], LED_pin2[0]);
					LL_GPIO_SetOutputPin(LED_port2[1], LED_pin2[1]);
					LL_GPIO_SetOutputPin(LED_port2[2], LED_pin2[2]);
					LL_GPIO_SetOutputPin(LED_port2[3], LED_pin2[3]);
					LL_GPIO_SetOutputPin(LED_port2[4], LED_pin2[4]);
					break;
				case 6:
					iterations=DELAY*0.5;
				  LL_GPIO_SetOutputPin(LED_port2[0], LED_pin2[0]);
					LL_GPIO_SetOutputPin(LED_port2[1], LED_pin2[1]);
					LL_GPIO_SetOutputPin(LED_port2[2], LED_pin2[2]);
					LL_GPIO_SetOutputPin(LED_port2[3], LED_pin2[3]);
					LL_GPIO_SetOutputPin(LED_port2[4], LED_pin2[4]);
					LL_GPIO_SetOutputPin(LED_port2[5], LED_pin2[5]);
					break;
				case 7:
					iterations=DELAY*0.2;
				  LL_GPIO_SetOutputPin(LED_port2[0], LED_pin2[0]);
					LL_GPIO_SetOutputPin(LED_port2[1], LED_pin2[1]);
					LL_GPIO_SetOutputPin(LED_port2[2], LED_pin2[2]);
					LL_GPIO_SetOutputPin(LED_port2[3], LED_pin2[3]);
					LL_GPIO_SetOutputPin(LED_port2[4], LED_pin2[4]);
					LL_GPIO_SetOutputPin(LED_port2[5], LED_pin2[5]);
					LL_GPIO_SetOutputPin(LED_port2[6], LED_pin2[6]);
					break;
				case 8:
					iterations=DELAY*0.1;
				  LL_GPIO_SetOutputPin(LED_port2[0], LED_pin2[0]);
					LL_GPIO_SetOutputPin(LED_port2[1], LED_pin2[1]);
					LL_GPIO_SetOutputPin(LED_port2[2], LED_pin2[2]);
					LL_GPIO_SetOutputPin(LED_port2[3], LED_pin2[3]);
					LL_GPIO_SetOutputPin(LED_port2[4], LED_pin2[4]);
					LL_GPIO_SetOutputPin(LED_port2[5], LED_pin2[5]);
					LL_GPIO_SetOutputPin(LED_port2[6], LED_pin2[6]);
					LL_GPIO_SetOutputPin(LED_port2[7], LED_pin2[7]);
					break;
			}
		}
		else{
			i=-1;
			LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_5);
			LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_6);
			LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_7);
			LL_GPIO_ResetOutputPin(GPIOB,LL_GPIO_PIN_6);
			LL_GPIO_ResetOutputPin(GPIOC,LL_GPIO_PIN_7);
			LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_9);
			LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_8);
			LL_GPIO_ResetOutputPin(GPIOB,LL_GPIO_PIN_10);
		}
    /* USER CODE END LL_EXTI_LINE_0 */
  }
  /* USER CODE BEGIN EXTI0_IRQn 1 */

  /* USER CODE END EXTI0_IRQn 1 */
}

/**
  * @brief This function handles EXTI line 1 interrupt.
  */
void EXTI1_IRQHandler(void)
{
	stopReply=1;
  /* USER CODE BEGIN EXTI1_IRQn 0 */
	delay100ms();
	
  /* USER CODE END EXTI1_IRQn 0 */
  if (LL_EXTI_IsActiveFlag_0_31(LL_EXTI_LINE_1) != RESET)
  {
    LL_EXTI_ClearFlag_0_31(LL_EXTI_LINE_1);
    /* USER CODE BEGIN LL_EXTI_LINE_1 */
		stopReply=0;
		
		if(settingsFlag==0){
			LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_5);
			LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_6);
			LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_7);
			LL_GPIO_ResetOutputPin(GPIOB,LL_GPIO_PIN_6);
			LL_GPIO_ResetOutputPin(GPIOC,LL_GPIO_PIN_7);
			LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_9);
			LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_8);
			LL_GPIO_ResetOutputPin(GPIOB,LL_GPIO_PIN_10);
			settingsFlag=1;
			delay100ms();
			switch(mode){
				case 1:
					iterations=DELAY*5;
					LL_GPIO_SetOutputPin(LED_port2[0], LED_pin2[0]);
					break;
				case 2:
					iterations=DELAY*4;
					LL_GPIO_SetOutputPin(LED_port2[0], LED_pin2[0]);
					LL_GPIO_SetOutputPin(LED_port2[1], LED_pin2[1]);
					break;
				case 3:
					iterations=DELAY*3;
				  LL_GPIO_SetOutputPin(LED_port2[0], LED_pin2[0]);
					LL_GPIO_SetOutputPin(LED_port2[1], LED_pin2[1]);
					LL_GPIO_SetOutputPin(LED_port2[2], LED_pin2[2]);
					break;
				case 4:
					iterations=DELAY*2;
				  LL_GPIO_SetOutputPin(LED_port2[0], LED_pin2[0]);
					LL_GPIO_SetOutputPin(LED_port2[1], LED_pin2[1]);
					LL_GPIO_SetOutputPin(LED_port2[2], LED_pin2[2]);
					LL_GPIO_SetOutputPin(LED_port2[3], LED_pin2[3]);
					break;
				case 5:
					iterations=DELAY*1;
				  LL_GPIO_SetOutputPin(LED_port2[0], LED_pin2[0]);
					LL_GPIO_SetOutputPin(LED_port2[1], LED_pin2[1]);
					LL_GPIO_SetOutputPin(LED_port2[2], LED_pin2[2]);
					LL_GPIO_SetOutputPin(LED_port2[3], LED_pin2[3]);
					LL_GPIO_SetOutputPin(LED_port2[4], LED_pin2[4]);
					break;
				case 6:
					iterations=DELAY*0.5;
				  LL_GPIO_SetOutputPin(LED_port2[0], LED_pin2[0]);
					LL_GPIO_SetOutputPin(LED_port2[1], LED_pin2[1]);
					LL_GPIO_SetOutputPin(LED_port2[2], LED_pin2[2]);
					LL_GPIO_SetOutputPin(LED_port2[3], LED_pin2[3]);
					LL_GPIO_SetOutputPin(LED_port2[4], LED_pin2[4]);
					LL_GPIO_SetOutputPin(LED_port2[5], LED_pin2[5]);
					break;
				case 7:
					iterations=DELAY*0.2;
				  LL_GPIO_SetOutputPin(LED_port2[0], LED_pin2[0]);
					LL_GPIO_SetOutputPin(LED_port2[1], LED_pin2[1]);
					LL_GPIO_SetOutputPin(LED_port2[2], LED_pin2[2]);
					LL_GPIO_SetOutputPin(LED_port2[3], LED_pin2[3]);
					LL_GPIO_SetOutputPin(LED_port2[4], LED_pin2[4]);
					LL_GPIO_SetOutputPin(LED_port2[5], LED_pin2[5]);
					LL_GPIO_SetOutputPin(LED_port2[6], LED_pin2[6]);
					break;
				case 8:
					iterations=DELAY*0.1;
				  LL_GPIO_SetOutputPin(LED_port2[0], LED_pin2[0]);
					LL_GPIO_SetOutputPin(LED_port2[1], LED_pin2[1]);
					LL_GPIO_SetOutputPin(LED_port2[2], LED_pin2[2]);
					LL_GPIO_SetOutputPin(LED_port2[3], LED_pin2[3]);
					LL_GPIO_SetOutputPin(LED_port2[4], LED_pin2[4]);
					LL_GPIO_SetOutputPin(LED_port2[5], LED_pin2[5]);
					LL_GPIO_SetOutputPin(LED_port2[6], LED_pin2[6]);
					LL_GPIO_SetOutputPin(LED_port2[7], LED_pin2[7]);
					break;
			}
		}
		else{
			settingsFlag=0;
			
			delay100ms();
			delay100ms();
			delay100ms();
			LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_5);
			LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_6);
			LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_7);
			LL_GPIO_ResetOutputPin(GPIOB,LL_GPIO_PIN_6);
			LL_GPIO_ResetOutputPin(GPIOC,LL_GPIO_PIN_7);
			LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_9);
			LL_GPIO_ResetOutputPin(GPIOA,LL_GPIO_PIN_8);
			LL_GPIO_ResetOutputPin(GPIOB,LL_GPIO_PIN_10);
		}
    /* USER CODE END LL_EXTI_LINE_1 */
  }
  /* USER CODE BEGIN EXTI1_IRQn 1 */

  /* USER CODE END EXTI1_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
