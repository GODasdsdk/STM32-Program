#ifndef __STATUS_H
#define __STATUS_H
extern int reverseFlag;
#endif