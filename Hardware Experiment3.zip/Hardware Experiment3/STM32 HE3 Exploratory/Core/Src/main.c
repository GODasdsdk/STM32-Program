/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* line IO pin and port */
GPIO_TypeDef * row_port[4] = {L1_GPIO_Port,L2_GPIO_Port,L3_GPIO_Port,L4_GPIO_Port};
uint32_t row_pin[4] = {L1_Pin,L2_Pin,L3_Pin,L4_Pin};

/* column IO pin and port */
GPIO_TypeDef * col_port[4] = {R1_GPIO_Port,R2_GPIO_Port,R3_GPIO_Port,R4_GPIO_Port};
uint32_t col_pin[4] = {R1_Pin,R2_Pin,R3_Pin,R4_Pin};

/* common anode LED character library */
// 0 1 2 3 4 5 6 7 8 9 A b C d E F -
const uint8_t LED_CODE[] = 
{
  0xF9,0xA4,0xB0,0x88,
	0x99,0x92,0x82,0x83,
	0xF8,0x80,0x90,0xC6,
	0x86,0xC0,0x8E,0xA1,
	0xBF
};

uint8_t LED[8]={0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF}; /* contents of LED display, 0xFF for dark */
unsigned char disp_ind=0; /* current bit location index of the LED display */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM7_Init(void);
int timer[8]={13,13,16,13,13,16,13,13};
int numtoindex[10]={0x0D,0,1,2,4,5,6,8,9,0x0A};
int bittochange=1;
int LEDporttochange[6]={0,1,3,4,6,7};
int toUpdatefor500ms=0;
int toUpdatefor1000ms=0;
int editmode=0;
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/**************
send one byte data to 74HC595
**************/
void out_595(uint8_t data)
{
  /* sent bit one by one */
  for(int i=0; i<8; i++){
    LL_GPIO_ResetOutputPin(SCLK_GPIO_Port,SCLK_Pin); //SCLK low
    
    /* output one bit */
    if((data<<i)&0x80)
      LL_GPIO_SetOutputPin(DIO_GPIO_Port,DIO_Pin);
    else
      LL_GPIO_ResetOutputPin(DIO_GPIO_Port,DIO_Pin);
    
    LL_GPIO_SetOutputPin(SCLK_GPIO_Port,SCLK_Pin); //SCL high, 74HC595 latch one bit
  }
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
	//timer[0]

  /* USER CODE BEGIN 1 */
	uint8_t i;
	uint8_t c_row=0;   /* current line number*/
	uint8_t c_col=0;   /* current column number */
	uint8_t key_value;  /* key value */


  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_SYSCFG);
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_PWR);

  /* System interrupt init*/
  NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_4);

  /* SysTick_IRQn interrupt configuration */
  NVIC_SetPriority(SysTick_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),15, 0));

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM7_Init();
  /* USER CODE BEGIN 2 */
	LL_TIM_ClearFlag_UPDATE(TIM7); // clear UIF before start timer
  LL_TIM_EnableIT_UPDATE(TIM7); // enable update interrupt
  LL_TIM_EnableCounter(TIM7); /* start tim7 count */
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		/* all line output high */
    for(i=0;i<4;i++)
      LL_GPIO_SetOutputPin(row_port[i],row_pin[i]);

    /* current line output low */
    LL_GPIO_ResetOutputPin(row_port[c_row],row_pin[c_row]);

    /* read column */
    for(c_col=0;c_col<4;c_col++){

      /* if current column is high, skip to next column, otherwise, key pressed */
      if(LL_GPIO_IsInputPinSet(col_port[c_col],col_pin[c_col]))
        continue;

      LL_mDelay(100); /* anti dither delay */

      /* if current column is still low (key pressed), otherwise skip to next line */
      if(LL_GPIO_IsInputPinSet(col_port[c_col],col_pin[c_col]))
        break;

      /* determine the key value */
      key_value = c_row*4+c_col;
      
			if(key_value==0x0E){
				if(editmode==0){
					bittochange=1;
					editmode=1;
				}
				else{
					editmode=0;
				}
				continue;
			}
			if(key_value==0x0C&&editmode==1){
				bittochange+=1;
				if(bittochange>6) bittochange=1;
				continue;
			}
			if(key_value==0x03) continue;
			if(key_value==0x07) continue;
			if(key_value==0x0B) continue;
			if(key_value==0x0F) continue;
			
			
			

      /* if the key is still pushed down, wait until it looses */
      while(!LL_GPIO_IsInputPinSet(col_port[c_col],col_pin[c_col]))
        continue;

      LL_mDelay(100); /* anti dither delay */

      break; /* break the column read 'for' loop, to next line */
    }

    /* update current row number for next line */
    if(++c_row > 3) c_row=0;
		if(editmode==1){
			for(int i=0;i<8;i++){
				
				if(i==LEDporttochange[bittochange-1]){
					if(toUpdatefor500ms==1){
						LED[i]=LED_CODE[timer[i]];
						toUpdatefor500ms=0;
						if(key_value==0x0C||key_value==0x0E||
							 key_value==0x03||key_value==0x07||
							 key_value==0x0B||key_value==0x0F) key_value=timer[i];
						switch(bittochange){
							case 1:
								LED[i]=LED_CODE[key_value];
								timer[i]=key_value;
								if(timer[6]!=0&&timer[6]!=1&&timer[6]!=13&&timer[7]==1){
									timer[6]=2;
									LED[6]=LED_CODE[2];
								}
								break;
							case 2:
								if(key_value!=6&&key_value!=8&&
									 key_value!=9&&key_value!=10){
										 LED[i]=LED_CODE[key_value];
										 timer[i]=key_value;
									 }
								else LED[i]=LED_CODE[timer[i]];
								break;
							case 3:
								LED[i]=LED_CODE[key_value];
								timer[i]=key_value;
								break;
							case 4:
								if(key_value!=6&&key_value!=8&&
									 key_value!=9&&key_value!=10){
										 LED[i]=LED_CODE[key_value];
										 timer[i]=key_value;
									 }
								else LED[i]=LED_CODE[timer[i]];
								break;
							case 5:
								LED[i]=LED_CODE[key_value];
								timer[i]=key_value;
								break;
							case 6:
								if(key_value!=6&&key_value!=8&&
									 key_value!=9&&key_value!=10&&
									 key_value!=2&&key_value!=3&&
									 key_value!=4&&key_value!=5){
										 LED[i]=LED_CODE[key_value];
										 timer[i]=key_value;
									 }
								else LED[i]=LED_CODE[timer[i]];
						}
						
					}
					else if(toUpdatefor500ms==2){
						LED[i]=0xFF;
						toUpdatefor500ms=0;
					}
				}
				else{
					LED[i]=LED_CODE[timer[i]];
				}
			}
		}
		else{
			if(timer[6]!=0&&timer[6]!=1&&timer[6]!=13&&timer[7]==1){
				timer[6]=2;
				LED[6]=LED_CODE[2];
			}
			int tonext1=0;
			int tonext2=0;
			int tonext3=0;
			int tonext4=0;
			int tonext5=0;
			for(int i=0;i<8;i++) LED[i]=LED_CODE[timer[i]];
			if(toUpdatefor1000ms==1){
				int h=0;
				int m=0;
				toUpdatefor1000ms=0;
				for(h=0;h<10;h++){
					if(numtoindex[h]==timer[0]) m=h;
				}
				if(m+1!=10){
					timer[0]=numtoindex[m+1];
				}else{
					timer[0]=0x0D;
					tonext1=1;
				}
			}
			if(tonext1==1){
				tonext1=0;
				int h=0;
				int m=0;
				for(h=0;h<6;h++){
					if(numtoindex[h]==timer[1]) m=h;
				}
				if(m+1!=6){
					timer[1]=numtoindex[m+1];
				}else{
					timer[1]=0x0D;
					tonext2=1;
				}
			}
			if(tonext2==1){
				tonext2=0;
				int h=0;
				int m=0;
				for(h=0;h<10;h++){
					if(numtoindex[h]==timer[3]) m=h;
				}
				if(m+1!=10){
					timer[3]=numtoindex[m+1];
				}else{
					timer[3]=0x0D;
					tonext3=1;
				}
			}
			if(tonext3==1){
				tonext3=0;
				int h=0;
				int m=0;
				for(h=0;h<6;h++){
					if(numtoindex[h]==timer[4]) m=h;
				}
				if(m+1!=6){
					timer[4]=numtoindex[m+1];
				}else{
					timer[4]=0x0D;
					tonext4=1;
				}
			}
			if(tonext4==1){
				tonext4=0;
				int h=0;
				int m=0;
				if(timer[7]==0x0C||timer[7]==0){
					for(h=0;h<10;h++){
						if(numtoindex[h]==timer[6]) m=h;
					}
					if(m+1!=10){
						timer[6]=numtoindex[m+1];
					}
					else{
						timer[6]=0x0D;
						tonext5=1;
					}
				}else{
					for(h=0;h<4;h++){
						if(numtoindex[h]==timer[6]) m=h;
					}
					if(m+1!=4){
						timer[6]=numtoindex[m+1];
					}
					else{
						timer[6]=0x0D;
						tonext5=1;
					}
				}
			}
			if(tonext5==1){
				tonext5=0;
				int h=0;
				int m=0;
				for(h=0;h<3;h++){
					if(numtoindex[h]==timer[7]) m=h;
				}
				if(m+1!=3){
					timer[7]=numtoindex[m+1];
				}else{
					timer[7]=0x0D;
				}
			}
		}
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  LL_FLASH_SetLatency(LL_FLASH_LATENCY_0);
  while(LL_FLASH_GetLatency()!= LL_FLASH_LATENCY_0)
  {
  }
  LL_PWR_SetRegulVoltageScaling(LL_PWR_REGU_VOLTAGE_SCALE3);
  LL_PWR_DisableOverDriveMode();
  LL_RCC_HSI_SetCalibTrimming(16);
  LL_RCC_HSI_Enable();

   /* Wait till HSI is ready */
  while(LL_RCC_HSI_IsReady() != 1)
  {

  }
  LL_RCC_SetAHBPrescaler(LL_RCC_SYSCLK_DIV_1);
  LL_RCC_SetAPB1Prescaler(LL_RCC_APB1_DIV_1);
  LL_RCC_SetAPB2Prescaler(LL_RCC_APB2_DIV_1);
  LL_RCC_SetSysClkSource(LL_RCC_SYS_CLKSOURCE_HSI);

   /* Wait till System clock is ready */
  while(LL_RCC_GetSysClkSource() != LL_RCC_SYS_CLKSOURCE_STATUS_HSI)
  {

  }
  LL_Init1msTick(16000000);
  LL_SetSystemCoreClock(16000000);
  LL_RCC_SetTIMPrescaler(LL_RCC_TIM_PRESCALER_TWICE);
}

/**
  * @brief TIM7 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM7_Init(void)
{

  /* USER CODE BEGIN TIM7_Init 0 */

  /* USER CODE END TIM7_Init 0 */

  LL_TIM_InitTypeDef TIM_InitStruct = {0};

  /* Peripheral clock enable */
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM7);

  /* TIM7 interrupt Init */
  NVIC_SetPriority(TIM7_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),0, 0));
  NVIC_EnableIRQ(TIM7_IRQn);

  /* USER CODE BEGIN TIM7_Init 1 */

  /* USER CODE END TIM7_Init 1 */
  TIM_InitStruct.Prescaler = 1599;
  TIM_InitStruct.CounterMode = LL_TIM_COUNTERMODE_UP;
  TIM_InitStruct.Autoreload = 9;
  LL_TIM_Init(TIM7, &TIM_InitStruct);
  LL_TIM_DisableARRPreload(TIM7);
  LL_TIM_SetTriggerOutput(TIM7, LL_TIM_TRGO_RESET);
  LL_TIM_DisableMasterSlaveMode(TIM7);
  /* USER CODE BEGIN TIM7_Init 2 */

  /* USER CODE END TIM7_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOA);
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOB);
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOC);

  /**/
  LL_GPIO_ResetOutputPin(GPIOA, SCLK_Pin|DIO_Pin|L3_Pin|L2_Pin);

  /**/
  LL_GPIO_ResetOutputPin(GPIOB, L4_Pin|RCLK_Pin);

  /**/
  LL_GPIO_ResetOutputPin(L1_GPIO_Port, L1_Pin);

  /**/
  GPIO_InitStruct.Pin = SCLK_Pin|DIO_Pin|L3_Pin|L2_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = L4_Pin|RCLK_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = L1_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(L1_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = R4_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_UP;
  LL_GPIO_Init(R4_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = R3_Pin|R1_Pin|R2_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_UP;
  LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
