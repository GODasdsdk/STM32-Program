/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* line IO pin and port */
GPIO_TypeDef * row_port[4] = {L1_GPIO_Port,L2_GPIO_Port,L3_GPIO_Port,L4_GPIO_Port};
uint32_t row_pin[4] = {L1_Pin,L2_Pin,L3_Pin,L4_Pin};

/* column IO pin and port */
GPIO_TypeDef * col_port[4] = {R1_GPIO_Port,R2_GPIO_Port,R3_GPIO_Port,R4_GPIO_Port};
uint32_t col_pin[4] = {R1_Pin,R2_Pin,R3_Pin,R4_Pin};

/* common anode LED character library */
// 0 1 2 3 4 5 6 7 8 9 A b C d E F -
const uint8_t LED_CODE[] = 
{
  0xF9,0xA4,0xB0,0x88,
	0x99,0x92,0x82,0x83,
	0xF8,0x80,0x90,0xC6,
	0x86,0xC0,0x8E,0xA1,
	0xBF
};

uint8_t LED[8]={0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF}; /* contents of LED display, 0xFF for dark */
unsigned char disp_ind=0; /* current bit location index of the LED display */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM7_Init(void);
int flow=0;//流动位置
int toUpdate=0;
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/**************
send one byte data to 74HC595
**************/
void out_595(uint8_t data)
{
  /* sent bit one by one */
  for(int i=0; i<8; i++){
    LL_GPIO_ResetOutputPin(SCLK_GPIO_Port,SCLK_Pin); //SCLK low
    
    /* output one bit */
    if((data<<i)&0x80)
      LL_GPIO_SetOutputPin(DIO_GPIO_Port,DIO_Pin);
    else
      LL_GPIO_ResetOutputPin(DIO_GPIO_Port,DIO_Pin);
    
    LL_GPIO_SetOutputPin(SCLK_GPIO_Port,SCLK_Pin); //SCL high, 74HC595 latch one bit
  }
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
	uint8_t i;
	uint8_t c_row=0;   /* current line number*/
	uint8_t c_col=0;   /* current column number */
	uint8_t key_value;  /* key value */


  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_SYSCFG);
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_PWR);

  /* System interrupt init*/
  NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_4);

  /* SysTick_IRQn interrupt configuration */
  NVIC_SetPriority(SysTick_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),15, 0));

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM7_Init();
  /* USER CODE BEGIN 2 */
	LL_TIM_ClearFlag_UPDATE(TIM7); // clear UIF before start timer
  LL_TIM_EnableIT_UPDATE(TIM7); // enable update interrupt
  LL_TIM_EnableCounter(TIM7); /* start tim7 count */
	int studentnum[11]={0,0,0,0,0,
											0,0,0,0,0,0xFF};//将学号第11位设置为空
	int inputFlag=0;
	int haventinput=1;//最开始哪个模式也不要进入
	int reverseFlag=0;
	int numindex=0;
	
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		/* all line output high */
    for(i=0;i<4;i++)
      LL_GPIO_SetOutputPin(row_port[i],row_pin[i]);

    /* current line output low */
    LL_GPIO_ResetOutputPin(row_port[c_row],row_pin[c_row]);

    /* read column */
    for(c_col=0;c_col<4;c_col++){

      /* if current column is high, skip to next column, otherwise, key pressed */
      if(LL_GPIO_IsInputPinSet(col_port[c_col],col_pin[c_col]))
        continue;

      LL_mDelay(100); /* anti dither delay */

      /* if current column is still low (key pressed), otherwise skip to next line */
      if(LL_GPIO_IsInputPinSet(col_port[c_col],col_pin[c_col]))
        break;

      /* determine the key value */
      key_value = c_row*4+c_col;
      
			if(key_value==0x0E){
				haventinput=0;
				if(inputFlag==0){
					reverseFlag=0;
					flow=0;
					inputFlag=1;
					numindex=0;
					for(int j=0;j<10;j++){
						studentnum[j]=0;
					}//清空学号中所有位
					for(int j=0;j<8;j++){
						LED[j]=0xFF;
					}
				}
				else{
					if(numindex>9) inputFlag=0;
				}
				break;
			}
			
			if(key_value==0x0C){
				if(inputFlag==0){
					if(reverseFlag==0) reverseFlag=1;
					else reverseFlag=0;
				}
				break;
			}
			
			if(inputFlag==1){//此时为输入学号模式
				if(numindex<10){
					for(i=7;i>0;i--) LED[i]=LED[i-1];
					LED[0]=LED_CODE[key_value];
					studentnum[numindex]=key_value;
					numindex++;
				}//学号位数未达到10的时候可以显示数字，达到10以后不再顶位输出
				//学号位数未达到10的时候可以记录数字，达到10以后不再记录
			}
			

      /* if the key is still pushed down, wait until it looses */
      while(!LL_GPIO_IsInputPinSet(col_port[c_col],col_pin[c_col]))
        continue;

      LL_mDelay(100); /* anti dither delay */

      break; /* break the column read 'for' loop, to next line */
    }

    /* update current row number for next line */
    if(++c_row > 3) c_row=0;
		if(inputFlag==0&&haventinput==0){//此时为流动模式
				if(toUpdate==1&&reverseFlag==0){
					flow++;
					toUpdate=0;
					if(flow==11) flow=0;
				}
				if(toUpdate==1&&reverseFlag==1){
					if(flow==0) flow=11;
					flow--;
					toUpdate=0;
				}
				switch(flow){
					case 0:
						for(int i=0;i<8;i++) LED[7-i]=LED_CODE[studentnum[i]];break;
					case 1:
						for(int i=0;i<8;i++) LED[7-i]=LED_CODE[studentnum[i+1]];break;
					case 2:
						for(int i=0;i<8;i++) LED[7-i]=LED_CODE[studentnum[i+2]];break;
					case 3:
						for(int i=0;i<8;i++) LED[7-i]=LED_CODE[studentnum[i+3]];break;
					case 4:
						for(int i=0;i<8;i++){
							if(i+4<11) LED[7-i]=LED_CODE[studentnum[i+4]];
							else LED[7-i]=LED_CODE[studentnum[i+4-11]];
						}
						break;
					case 5:
						for(int i=0;i<8;i++){
							if(i+5<11) LED[7-i]=LED_CODE[studentnum[i+5]];
							else LED[7-i]=LED_CODE[studentnum[i+5-11]];
						}
						break;
					case 6:
						for(int i=0;i<8;i++){
							if(i+6<11) LED[7-i]=LED_CODE[studentnum[i+6]];
							else LED[7-i]=LED_CODE[studentnum[i+6-11]];
						}
						break;
					case 7:
						for(int i=0;i<8;i++){
							if(i+7<11) LED[7-i]=LED_CODE[studentnum[i+7]];
							else LED[7-i]=LED_CODE[studentnum[i+7-11]];
						}
						break;
					case 8:
						for(int i=0;i<8;i++){
							if(i+8<11) LED[7-i]=LED_CODE[studentnum[i+8]];
							else LED[7-i]=LED_CODE[studentnum[i+8-11]];
						}
						break;
					case 9:
						for(int i=0;i<8;i++){
							if(i+9<11) LED[7-i]=LED_CODE[studentnum[i+9]];
							else LED[7-i]=LED_CODE[studentnum[i+9-11]];
						}
						break;
					case 10:
						for(int i=0;i<8;i++){
							if(i+10<11) LED[7-i]=LED_CODE[studentnum[i+10]];
							else LED[7-i]=LED_CODE[studentnum[i+10-11]];
						}
						break;
						
				}
				
				
			}

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  LL_FLASH_SetLatency(LL_FLASH_LATENCY_0);
  while(LL_FLASH_GetLatency()!= LL_FLASH_LATENCY_0)
  {
  }
  LL_PWR_SetRegulVoltageScaling(LL_PWR_REGU_VOLTAGE_SCALE3);
  LL_PWR_DisableOverDriveMode();
  LL_RCC_HSI_SetCalibTrimming(16);
  LL_RCC_HSI_Enable();

   /* Wait till HSI is ready */
  while(LL_RCC_HSI_IsReady() != 1)
  {

  }
  LL_RCC_SetAHBPrescaler(LL_RCC_SYSCLK_DIV_1);
  LL_RCC_SetAPB1Prescaler(LL_RCC_APB1_DIV_1);
  LL_RCC_SetAPB2Prescaler(LL_RCC_APB2_DIV_1);
  LL_RCC_SetSysClkSource(LL_RCC_SYS_CLKSOURCE_HSI);

   /* Wait till System clock is ready */
  while(LL_RCC_GetSysClkSource() != LL_RCC_SYS_CLKSOURCE_STATUS_HSI)
  {

  }
  LL_Init1msTick(16000000);
  LL_SetSystemCoreClock(16000000);
  LL_RCC_SetTIMPrescaler(LL_RCC_TIM_PRESCALER_TWICE);
}

/**
  * @brief TIM7 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM7_Init(void)
{

  /* USER CODE BEGIN TIM7_Init 0 */

  /* USER CODE END TIM7_Init 0 */

  LL_TIM_InitTypeDef TIM_InitStruct = {0};

  /* Peripheral clock enable */
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM7);

  /* TIM7 interrupt Init */
  NVIC_SetPriority(TIM7_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),0, 0));
  NVIC_EnableIRQ(TIM7_IRQn);

  /* USER CODE BEGIN TIM7_Init 1 */

  /* USER CODE END TIM7_Init 1 */
  TIM_InitStruct.Prescaler = 1599;
  TIM_InitStruct.CounterMode = LL_TIM_COUNTERMODE_UP;
  TIM_InitStruct.Autoreload = 9;
  LL_TIM_Init(TIM7, &TIM_InitStruct);
  LL_TIM_DisableARRPreload(TIM7);
  LL_TIM_SetTriggerOutput(TIM7, LL_TIM_TRGO_RESET);
  LL_TIM_DisableMasterSlaveMode(TIM7);
  /* USER CODE BEGIN TIM7_Init 2 */

  /* USER CODE END TIM7_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOA);
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOB);
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOC);

  /**/
  LL_GPIO_ResetOutputPin(GPIOA, SCLK_Pin|DIO_Pin|L3_Pin|L2_Pin);

  /**/
  LL_GPIO_ResetOutputPin(GPIOB, L4_Pin|RCLK_Pin);

  /**/
  LL_GPIO_ResetOutputPin(L1_GPIO_Port, L1_Pin);

  /**/
  GPIO_InitStruct.Pin = SCLK_Pin|DIO_Pin|L3_Pin|L2_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = L4_Pin|RCLK_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = L1_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(L1_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = R4_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_UP;
  LL_GPIO_Init(R4_GPIO_Port, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = R3_Pin|R1_Pin|R2_Pin;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_UP;
  LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
